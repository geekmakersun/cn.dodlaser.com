<?php

return [

    'type' => 'app',
    'name' => '网站终端',
    'author' => '迅睿云软件',
    'icon' => 'fa fa-cogs',

];