<?php

/**
 * 菜单配置
 */


return [

    'admin' => [

        'app' => [

            'left' => [


                // 集成单个菜单
                'app-plugin' => [
                    'link' => [
                        'app-client' => [
                            'name' => '网站多终端',
                            'icon' => 'fa fa-cogs',
                            'uri' => 'client/config/index',
                        ],

                    ]
                ],



            ],



        ],





    ],



];