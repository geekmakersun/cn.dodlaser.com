<?php namespace Phpcmf\Model\Module;
/**
 * {{www.xunruicms.com}}
 * {{迅睿内容管理框架系统}}
 * 本文件是框架系统文件，二次开发时不可以修改本文件，可以通过继承类方法来重写此文件
 **/

// 模型类

class Urlrule extends \Phpcmf\Model {

    // 缓存
    public function cache($site = SITE_ID) {



        return;
    }
    
}