<?php

/**
 * 菜单配置
 */


return [

    'admin' => [

        'app' => [

            'left' => [

                // 集成单个菜单
                'app-plugin' => [
                    'link' => [
                        'app-baidumap' => [
                            'name' => '百度地图字段',
                            'icon' => 'fa fa-map',
                            'uri' => 'baidumap/config/index',
                        ],

                    ]
                ],





            ],



        ],





    ],



];