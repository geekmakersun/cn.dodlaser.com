<?php

return [

    'type' => 'app',
    'name' => '百度地图字段',
    'author' => '迅睿云软件',
    'icon' => 'fa fa-map',

];