<?php

/**
 * 可用字段
 * id  插件目录名::文件名称
 * name 显示名称
 * used 数组 表示可以用到哪些地方
 * namespace 是哪个app专属的
 */

return [
    [
        'id' => 'Baidumap::Baidumap',
        'name' => 'Baidumap',
        'used' => '',
        'namespace' => '',
    ],
];