<?php namespace Phpcmf\Controllers\Admin;

class Home extends \Phpcmf\Table
{
    private $form; // 表单验证配置

    public function __construct() {
        parent::__construct();
        \Phpcmf\Service::V()->assign('menu', \Phpcmf\Service::M('auth')->_admin_menu(
            [
                '多网站管理' => ['sites/home/index', 'fa fa-share-alt'],
                '创建站点' => ['sites/home/add', 'fa fa-plus'],
                '域名绑定说明' => ['sites/home/bang_index', 'fa fa-code'],
                'help' => ['384'],
            ]
        ));
        // 表单验证配置
        $this->form = [
            'name' => [
                'name' => '站点名称',
                'rule' => [
                    'empty' => dr_lang('站点名称不能为空')
                ],
                'filter' => [],
                'length' => '200'
            ],
            'domain' => [
                'name' => '域名地址',
                'filter' => [],
                'length' => '200'
            ],
        ];
    }

    public function index() {

        $this->_init([
            'table' => 'site',
            'order_by' => 'displayorder ASC,id ASC',
        ]);
        $this->_List();
        \Phpcmf\Service::V()->display('site_index.html');
    }

    // 克隆
    public function cp_index() {

        $id = (int)\Phpcmf\Service::L('input')->get('id');

        if (IS_POST) {

            if (!IS_USE_MODULE) {
                $this->_json(0, dr_lang('没有[安装内容系统]插件，无法使用此功能'));
            }

            $post = \Phpcmf\Service::L('input')->post('data');
            if (!$post['data']) {
                $this->_json(0, dr_lang('请选择克隆的数据项'));
            } elseif (!$post['siteid']) {
                $this->_json(0, dr_lang('请选择克隆的母站点'));
            } elseif ($id == $post['siteid']) {
                $this->_json(0, dr_lang('母站点不能与当前站点相同'));
            }

            $ttable = $post['siteid'].'_share_category'; // 数据站点
            if (!\Phpcmf\Service::M()->db->tableExists(\Phpcmf\Service::M()->dbprefix($ttable))) {
                $this->_json(0, dr_lang('母站点栏目表未创建'));
            }

            $tdata = \Phpcmf\Service::M()->table($ttable)->getAll();
            if (!$tdata) {
                $this->_json(0, dr_lang('母站点栏目数据为空'));
            }

            $ftable = $id.'_share_category'; // 新站点
            if (!\Phpcmf\Service::M()->db->tableExists(\Phpcmf\Service::M()->dbprefix($ftable))) {
                $this->_json(0, dr_lang('新站点栏目表未创建'));
            }
            foreach ($tdata as $t) {
                \Phpcmf\Service::M()->table($ftable)->replace($t);
            }

            $tdata = \Phpcmf\Service::M()->table($ftable)->counts();
            $this->_json(1, dr_lang('为站点[%s]共创建了%s个共享栏目', $id, $tdata), -1);
        }


        \Phpcmf\Service::V()->assign([
            'form' => dr_form_hidden(),
            'siteid' => $id,
        ]);
        \Phpcmf\Service::V()->display('site_cp.html');
    }

    public function add() {

        if (IS_AJAX_POST) {
            $data = $this->_validation(\Phpcmf\Service::L('input')->post('data'));
            \Phpcmf\Service::L('input')->system_log('创建网站('.$data['name'].')');
            $siteid = \Phpcmf\Service::M('site')->create($data);
            $t = \Phpcmf\Service::M()->table('site')->get($siteid);
            if ($t) {
                $obj = \Phpcmf\Service::M('site', 'module');
                if (method_exists($obj, 'update_site_sync')) {
                    $obj->update_site_sync($t);
                }
            } else {
                $this->_json(0, dr_lang('创建失败'));
            }
            $this->_json(1, dr_lang('操作成功，请手动更新缓存'));
        }

        \Phpcmf\Service::V()->assign([
            'form' => dr_form_hidden()
        ]);
        \Phpcmf\Service::V()->display('site_add.html');
    }

    // 隐藏或者启用
    public function hidden_edit() {

        $id = (int)\Phpcmf\Service::L('input')->get('id');
        if ($id == 1) {
            $this->_json(0, dr_lang('主站不能禁用'));
        }
        $row = \Phpcmf\Service::M()->table('site')->get($id);
        if (!$row) {
            $this->_json(0, dr_lang('站点数据不存在'));
        }

        $v = $row['disabled'] ? 0 : 1;
        \Phpcmf\Service::M('Site')->table('site')->update($id, ['disabled' => $v]);
        \Phpcmf\Service::M('cache')->sync_cache('');

        $this->_json(1, dr_lang($v ? '站点已被禁用' : '站点已被启用'), ['value' => $v]);
    }

    public function del() {

        $ids = \Phpcmf\Service::L('input')->get_post_ids();
        if (!$ids) {
            $this->_json(0, dr_lang('你还没有选择呢'));
        } elseif (in_array(1, $ids)) {
            $this->_json(0, dr_lang('主站不能删除'));
        }

        $rt = \Phpcmf\Service::M('sites', 'sites')->delete_site($ids);
        if (!$rt['code']) {
            $this->_json(0, $rt['msg']);
        }

        \Phpcmf\Service::M('cache')->sync_cache('');
        \Phpcmf\Service::L('input')->system_log('批量删除站点: '. @implode(',', $ids));

        $this->_json(1, dr_lang('操作成功'), ['ids' => $ids]);
    }

    // 排序
    public function displayorder_edit() {

        // 查询数据
        $id = (int)\Phpcmf\Service::L('input')->get('id');
        $row = \Phpcmf\Service::M()->table('site')->get($id);
        if (!$row) {
            $this->_json(0, dr_lang('数据#%s不存在', $id));
        }

        $value = (int)\Phpcmf\Service::L('input')->get('value');
        $rt = \Phpcmf\Service::M()->table('site')->save($id, 'displayorder', $value);
        if (!$rt['code']) {
            $this->_json(0, $rt['msg']);
        }

        \Phpcmf\Service::M('cache')->sync_cache(''); // 自动更新缓存
        \Phpcmf\Service::L('input')->system_log('修改站点('.$row['name'].')的排序值为'.$value);
        $this->_json(1, dr_lang('操作成功'));
    }

    public function edit() {

        $ids = \Phpcmf\Service::L('input')->get_post_ids();
        if (!$ids) {
            $this->_json(0, dr_lang('你还没有选择呢'));
        }

        $data = \Phpcmf\Service::M()->db->table('site')->whereIn('id', $ids)->get()->getResultArray();
        $value = \Phpcmf\Service::L('input')->post('data', true);
        foreach ($data as $t) {
            $id = $t['id'];
            $t['setting'] = dr_string2array($t['setting']);
            $t['setting']['webpath'] = $id > 1 ? $value[$id]['webpath'] : '';
            \Phpcmf\Service::M()->db->table('site')->where('id', $id)->update([
                'name' => $value[$id]['name'] ? $value[$id]['name'] : '未知',
                'domain' => $value[$id]['domain'] ? $value[$id]['domain'] : 'null',
                'setting' => dr_array2string($t['setting'])
            ]);
        }

        \Phpcmf\Service::M('cache')->sync_cache('');
        \Phpcmf\Service::L('input')->system_log('批量修改站点: '. @implode(',', $ids));

        $this->_json(1, dr_lang('操作成功'));
    }

    public function bang_index() {
        \Phpcmf\Service::V()->display('site_bang.html');
    }

    public function menu_index() {

        $id = intval($_GET['id']);
        $data = \Phpcmf\Service::M('menu')->gets('admin');

        if (IS_POST) {
            $ids = \Phpcmf\Service::L('input')->get_post_ids();
            if (!$ids) {
                $this->_json(0, dr_lang('你还没有选择呢'));
            }
            foreach ($data as $t) {
                $site = dr_string2array($t['site']);
                if (in_array($t['id'], $ids)) {
                    // 增加权限
                    $site[$id] = $id;
                } else {
                    // 取消权限
                    unset($site[$id]);
                }
                \Phpcmf\Service::M()->db->table('admin_menu')->where('id', $t['id'])->update([
                    'site' => dr_array2string($site)
                ]);
            }
            \Phpcmf\Service::M('cache')->sync_cache(''); // 自动更新缓存
            $this->_json(1, dr_lang('操作成功'));
        }

        \Phpcmf\Service::V()->assign([
            'data' => $data,
            'siteid' => $id,
        ]);
        \Phpcmf\Service::V()->display('menu_index.html');exit;
    }



    // 验证数据
    private function _validation($data) {

        list($data, $return) = \Phpcmf\Service::L('Form')->validation($data, $this->form);
        if ($return) {
            $this->_json(0, $return['error'], ['field' => $return['name']]);
        }

        if ($data['mode']) {
            // 目录模式
            if (!$data['dirname']) {
                $this->_json(0, dr_lang('本站目录未填写'), ['field' => 'dirname']);
            } elseif (strpos($data['dirname'], '/') !== false) {
                $this->_json(0, dr_lang('本站目录填写格式有误，只能填写相当于本站根目录的文件名称'), ['field' => 'dirname']);
            }
            $data['domain'] = $this->site_info[SITE_ID]['SITE_DOMAIN'].'/'.$data['dirname'];
            $data['webpath'] = $data['dirname'];
        } else {
            if (!$data['webpath']) {
                $this->_json(0, dr_lang('本站Web目录未填写'), ['field' => 'webpath']);
            }
        }

        unset($data['mode']);
        unset($data['dirname']);

        $path = dr_get_dir_path($data['webpath']);
        dr_mkdirs($path);

        if (!is_dir($path)) {
            $this->_json(0, dr_lang('目录[%s]不存在', $path));
        } elseif (is_file($path.'index.php')) {
            $this->_json(0, dr_lang('目录[%s]已经创建过站点，请更换目录', $path));
        }

        //

        return $data;
    }


}
