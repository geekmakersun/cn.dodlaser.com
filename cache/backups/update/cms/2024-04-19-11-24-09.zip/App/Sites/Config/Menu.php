<?php

/**
 * 菜单配置
 */


return [

    'admin' => [

        'app' => [

            'left' => [


                'app-plugin' => [
                    'link' => [
                        'app-sites' => [
                            'name' => '多网站管理',
                            'icon' => 'fa fa-share-alt',
                            'uri' => 'sites/home/index',
                        ],
                    ]
                ],
            ],



        ],

    ],
];