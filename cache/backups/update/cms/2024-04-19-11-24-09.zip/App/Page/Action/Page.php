<?php

$data = \Phpcmf\Service::C()->get_cache('page-'.$system['site'], 'data'); // 单页缓存
if (!$data) {
    return $this->_return($system['return'], '没有查询到内容');
}

$i = 0;
$show = isset($param['show']) ? 1 : 0; // 有show参数表示显示隐藏栏目
$return = [];
foreach ($data as $id => $t) {
    if (!is_numeric($id)) {
        continue;
    } elseif ($system['num'] && $i >= $system['num']) {
        break;
    } elseif (!$t['show'] && !$show) {
        continue;
    } elseif (isset($param['pid']) && $t['pid'] != (int) $param['pid']) {
        continue;
    } elseif (isset($param['id']) && !in_array($t['id'], explode(',', $param['id']))) {
        continue;
    }
    $t['setting'] = dr_string2array($t['setting']);
    $return[] = $t;
    $i ++;
}

if (!$return) {
    return $this->_return($system['return'], '没有匹配到内容');
}

return $this->_return($system['return'], $return, '');