<?php
/** 卸载操作
 */

foreach ($this->site as $siteid) {
    $this->db->table('field')->where('relatedid', $siteid)->where('relatedname', 'page')->delete();
}