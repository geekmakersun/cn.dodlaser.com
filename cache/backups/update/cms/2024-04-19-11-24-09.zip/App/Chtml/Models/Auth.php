<?php namespace Phpcmf\Model\Chtml;

// 权限验证
class Auth extends \Phpcmf\Model
{
    // 判断底部链接的显示权限
    public function is_bottom_auth($mid) {
        return 1;// 表示都有权限
    }

}