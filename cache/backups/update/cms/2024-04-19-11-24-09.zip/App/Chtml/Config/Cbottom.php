<?php

return [

    [
        'name' => '生成静态',// 批量权限是插件的链接名称
        'icon' => 'fa fa-html5', // 图标
        'url' => 'javascript:;" onclick="dr_scjt()',
        'uri' => 'chtml/html/index', // 对应的uri权限判断，后面章节会介绍权限写法
    ],

];
