<?php

return [

    'id' => '783',
    'vip' => '1',
    'cms' => '4.6.2',
    'version' => '1.36',
    'license' => '5E632913BF096E49880CF8B92D53C99711',
    'updatetime' => '2024-03-25 15:27:44',
    'downtime' => '2024-04-19 07:38:13',

];
