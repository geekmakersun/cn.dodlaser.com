<?php

return [

    'type' => 'app',
    'name' => '内容静态生成',
    'author' => '迅睿云软件',
    'icon' => 'fa fa-file-text',
    'uri' => 'chtml/config/index'

];