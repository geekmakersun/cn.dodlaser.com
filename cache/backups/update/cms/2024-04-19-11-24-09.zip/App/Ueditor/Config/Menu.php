<?php

/**
 * 菜单配置
 */


return [

    'admin' => [

        'app' => [

            'left' => [


                // 集成单个菜单
                'app-plugin' => [
                    'link' => [
                        'app-ueditor' => [
                            'name' => 'Ueditor编辑器',
                            'icon' => 'fa fa-edit',
                            'uri' => 'ueditor/config/index',
                        ],

                    ]
                ],




            ],



        ],





    ],



];