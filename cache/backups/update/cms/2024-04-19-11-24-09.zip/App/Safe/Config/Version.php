<?php

return [

    'id' => '399',
    'vip' => '1',
    'cms' => '4.6.2',
    'version' => '4.5',
    'license' => '5E632913BF096E49880CF8B92D53C99711',
    'updatetime' => '2024-04-01 18:39:49',
    'downtime' => '2024-04-19 07:38:13',

];
