<?php

return [

    'type' => 'app',
    'name' => '蜘蛛监控',
    'author' => '迅睿云软件',
    'icon' => 'fa fa-bug',

];