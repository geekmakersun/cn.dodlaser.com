<?php

return [

    'id' => '893',
    'vip' => '1',
    'cms' => '4.6.2',
    'version' => '1.16',
    'license' => '5E632913BF096E49880CF8B92D53C99711',
    'updatetime' => '2024-02-15 11:09:05',
    'downtime' => '2024-04-18 20:58:52',

];
