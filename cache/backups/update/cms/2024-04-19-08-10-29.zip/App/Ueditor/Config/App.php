<?php

return [

    'type' => 'app',
    'name' => 'Ueditor编辑器',
    'author' => '迅睿云软件',
    'icon' => 'fa fa-edit',

];