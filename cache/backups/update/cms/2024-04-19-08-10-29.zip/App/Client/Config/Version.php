<?php

return [

    'id' => '835',
    'vip' => '1',
    'cms' => '4.6.2',
    'version' => '1.6',
    'license' => '5E632913BF096E49880CF8B92D53C99711',
    'updatetime' => '2024-01-16 09:43:59',
    'downtime' => '2024-04-18 20:58:52',

];
