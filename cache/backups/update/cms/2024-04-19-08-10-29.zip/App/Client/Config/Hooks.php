<?php

if (!function_exists('dr_client_url')) {
    function dr_client_url($name) {
        $data = \Phpcmf\Service::M('Site')->config(SITE_ID);
        if ($name && $data['client']) {
            foreach ($data['client'] as $t) {
                if ($t['name'] == $name) {
                    return dr_http_prefix($t['domain'].'/');
                }
            }
        }
        return SITE_URL;
    }
}