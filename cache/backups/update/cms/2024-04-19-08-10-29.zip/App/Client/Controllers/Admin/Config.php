<?php namespace Phpcmf\Controllers\Admin;

class Config extends \Phpcmf\Common
{

    public function index() {

        $cfile = WRITEPATH.'config/app_client.php';

        if (IS_AJAX_POST) {
            $save = [];
            $dir = \Phpcmf\Service::L('input')->post('dir');
            $name = \Phpcmf\Service::L('input')->post('name');
            $domain = \Phpcmf\Service::L('input')->post('domain');
            if ($dir) {
                $cname = [];
                foreach ($dir as $i => $t) {
                    $i = intval($i);
                    if (!$t) {
                        $this->_json(0, dr_lang('终端目录必须填写'));
                    } elseif (!preg_match('/^[a-z]+/i', $t)) {
                        $this->_json(0, dr_lang('终端目录必须是英文字母'));
                    } elseif (in_array($t, [SITE_MOBILE_DIR, 'pc', 'api'])) {
                        $this->_json(0, dr_lang('不能使用系统内置目录：%s', $t));
                    } elseif (!isset($name[$i]) || !$name[$i]) {
                        $this->_json(0, dr_lang('终端名称必须填写'));
                    } elseif (!isset($domain[$i]) || !$domain[$i]) {
                        $this->_json(0, dr_lang('终端域名必须填写'));
                    } elseif (strpos($domain[$i], '//') !== false) {
                        $this->_json(0, dr_lang('域名只能填写纯域名，不能加http://'));
                    } elseif (!\Phpcmf\Service::L('Form')->check_domain_dir($domain[$i])) {
                        $this->_json(0, dr_lang('域名（%s）格式不正确', $domain[$i]));
                    } elseif ($this->site_info[SITE_ID]['SITE_DOMAIN'] == $domain[$i]) {
                        $this->_json(0, dr_lang('域名（%s）已经其他地方绑定过', $domain[$i]));
                    }
                    $save[$i] = [
                        'name' => dr_safe_replace($dir[$i]),
                        'domain' => dr_safe_replace($domain[$i]),
                    ];
                    $cname[$dir[$i]] = dr_safe_replace($name[$i]);
                }
                // 存储终端
                \Phpcmf\Service::L('Config')->file($cfile, '多终端的配置文件', 32)->to_require($cname);
            }

            $rt = \Phpcmf\Service::M('Site')->save_config(
                SITE_ID,
                'client',
                $save
            );
            if (!is_array($rt)) {
                $this->_json(0, dr_lang('网站终端(#%s)不存在', SITE_ID));
            }
            \Phpcmf\Service::M('cache')->sync_cache('');
            \Phpcmf\Service::L('input')->system_log('设置网站自定义终端参数');
            $this->_json(1, dr_lang('操作成功'));
        }

        $page = intval(\Phpcmf\Service::L('input')->get('page'));
        $data = \Phpcmf\Service::M('Site')->config(SITE_ID);
        list($module, $domain) = \Phpcmf\Service::M('Site')->domain();

        \Phpcmf\Service::V()->assign([
            'page' => $page,
            'data' => $data['client'],
            'form' => dr_form_hidden(['page' => $page]),
            'menu' => \Phpcmf\Service::M('auth')->_admin_menu(
                [
                    '网站终端' => ['client/config/index', 'fa fa-cogs'],
                    'help' => [478],
                ]
            ),
            'client' => \Phpcmf\Service::R(WRITEPATH.'config/app_client.php'),
            'pc_domain' => $domain['site_domain'],
            'mobile_domain' => $domain['mobile_domain'],
        ]);
        \Phpcmf\Service::V()->display('config.html');
    }

    public function seo_index() {

        $cid = dr_safe_filename(\Phpcmf\Service::L('input')->get('id'));
        $cfile = WRITEPATH.'config/app_client_seo.php';
        $cdata = \Phpcmf\Service::R($cfile);
        if (IS_AJAX_POST) {
            $cdata[$cid] = \Phpcmf\Service::L('input')->post('data');
            // 存储终端
            \Phpcmf\Service::L('Config')->file($cfile, '多终端的SEO信息', 32)->to_require($cdata);
            $this->_json(1, dr_lang('操作成功'));
        }

        \Phpcmf\Service::V()->assign([
            'form' => dr_form_hidden(),
            'data' => isset($cdata[$cid]) && $cdata[$cid] ? $cdata[$cid] : [],
        ]);
        \Phpcmf\Service::V()->display('seo.html');
    }


}
