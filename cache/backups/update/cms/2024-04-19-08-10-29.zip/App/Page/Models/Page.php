<?php namespace Phpcmf\Model\Page;

// 单页模型类

class Page extends \Phpcmf\Model
{

    protected $tablename;
    protected $categorys;

    public function __construct()
    {
        parent::__construct();
        $this->tablename = SITE_ID.'_page';
    }

    // 复制属性
    public function copy_value($at, $setting, $id) {

        $row = $this->table($this->tablename)->get($id);
        if (!$row) {
            return;
        }

        $row['setting'] = dr_string2array($row['setting']);
        if ($at == 'tpl') {
            $row['setting']['template'] = $setting['template'];
        } elseif ($at == 'seo') {
            $row['setting']['seo'] = $setting['seo'];
            $row['setting']['html'] = $setting['html'];
            $row['setting']['urlrule'] = $setting['urlrule'];
            $row['setting']['urlrule_page'] = $setting['urlrule_page'];
        } else {
            $row['setting'][$at] = $setting[$at];
        }

        $this->table($this->tablename)->update($id, [
            'setting' => dr_array2string($row['setting']),
        ]);
    }

    // 设置默认表
    public function set_siteid($id) {
        $this->tablename = $id.'_page';
        return $this;
    }

    // 检查目录是否可用
    public function check_dirname($id, $value) {

        if (defined('SYS_PAGE_RNAME') && SYS_PAGE_RNAME) {
            return 0;
        }

        if (!$value['dirname']) {
            return 1;
        } elseif ($value['dirname'] == '/') {
            return 0;
        }
        $value['setting'] = dr_string2array($value['setting']);
        if ($value['setting']['html']) {
            // 静态模式不验证目录格式
            if ($value['setting']['html_domain']) {
                // 绑定域名时不验证目录可用性
                return 0;
            }
        } else {
            if (!preg_match('/^[a-z0-9]*$/i', $value['dirname'])) {
                return 1;
            }
        }

        return $this->table($this->tablename)->is_exists($id, 'dirname', $value['dirname']);
    }

    /**
     * 获取父栏目ID列表
     *
     * @param	integer	$catid	栏目ID
     * @param	array	$pids	父目录ID
     * @param	integer	$n		查找的层次
     * @return	string
     */
    private function get_pids($catid, $pids = '', $n = 1) {

        if ($n > 100 || !is_array($this->categorys)
            || !isset($this->categorys[$catid])) {
            return FALSE;
        }

        $pid = $this->categorys[$catid]['pid'];
        $pids = $pids ? $pid.','.$pids : $pid;
        $pid ? $pids = $this->get_pids($pid, $pids, ++$n) : $this->categorys[$catid]['pids'] = $pids;

        return $pids;
    }

    /**
     * 获取子栏目ID列表
     *
     * @param	$catid	栏目ID
     * @return	string
     */
    private function get_childids($catid, $n = 1) {

        $childids = $catid;

        if ($n > 100 || !is_array($this->categorys)
            || !isset($this->categorys[$catid])) {
            return $childids;
        }

        if (is_array($this->categorys)) {
            foreach ($this->categorys as $id => $cat) {
                $cat['pid'] && $id != $catid && $cat['pid'] == $catid && $childids.= ','.$this->get_childids($id, ++$n);
            }
        }

        return $childids;
    }

    /**
     * 所有父目录
     *
     * @param	$catid	��ĿID
     * @return	string
     */
    public function get_pdirname($catid) {

        if ($this->categorys[$catid]['pid'] == 0) {
            return '';
        }

        $t = $this->categorys[$catid];
        $pids = $t['pids'];
        $pids = explode(',', $pids);
        $catdirs = array();
        krsort($pids);

        foreach ($pids as $id) {
            if ($id == 0) {
                continue;
            }
            $catdirs[] = $this->categorys[$id]['dirname'];
            if ($this->categorys[$id]['pdirname'] == '') {
                break;
            }
        }
        krsort($catdirs);

        return implode('/', $catdirs).'/';
    }

    /**
     * 修复菜单数据
     */
    public function repair($_data = []) {

        $this->categorys = $categorys = [];
        if (!$_data) {
            $_data = $this->table($this->tablename)->order_by('displayorder ASC,id ASC')->getAll();
            if (!$_data) {
                return NULL;
            }
        }

        foreach ($_data as $t) {
            $t['setting'] = dr_string2array($t['setting']);
            $categorys[$t['id']] = $t;
        }

        $this->categorys = $categorys; // 全部栏目数据
        if (is_array($this->categorys)) {
            foreach ($this->categorys as $catid => $cat) {

                $this->categorys[$catid]['pids'] = $this->get_pids($catid);
                $this->categorys[$catid]['childids'] = $this->get_childids($catid);
                $this->categorys[$catid]['child'] = is_numeric($this->categorys[$catid]['childids']) ? 0 : 1;
                $this->categorys[$catid]['pdirname'] = $this->get_pdirname($catid);

                if ($cat['pdirname'] != $this->categorys[$catid]['pdirname']
                    || $cat['pids'] != $this->categorys[$catid]['pids']
                    || $cat['childids'] != $this->categorys[$catid]['childids']
                    || $cat['child'] != $this->categorys[$catid]['child']) {
                    // 当库中与实际不符合才更新数据表
                    // 更新数据库
                    $this->table($this->tablename)->update($cat['id'], array(
                        'pids' => $this->categorys[$catid]['pids'],
                        'child' => $this->categorys[$catid]['child'],
                        'childids' => $this->categorys[$catid]['childids'],
                        'pdirname' => $this->categorys[$catid]['pdirname']
                    ));
                }

                $pid = explode(',', $cat['pids']);
                $cat['topid'] = isset($pid[1]) ? $pid[1] : $cat['id'];
                if ($cat['topid'] && $cat['topid'] != $cat['id']) {
                    // 继承第一级的
                    $this->categorys[$catid]['setting']['html_domain'] = $this->categorys[$cat['topid']]['setting']['html_domain'];
                    $this->categorys[$catid]['setting']['html_mobile_domain'] = $this->categorys[$cat['topid']]['setting']['html_mobile_domain'];
                }
            }
        }

        return $this->categorys;
    }

    // 更新URL
    public function _update_url($data, $siteid = SITE_ID) {

        $data['setting'] = dr_string2array($data['setting']);
        $url = $data['setting']['urllink'] ? $data['setting']['urllink'] : $this->page_url($data, 0, $siteid);
        $this->db->table($siteid.'_page')->where('id', $data['id'])->update(['url' => $url]);
        return $url;
    }

    /*
     * 单页URL地址
     *
     * @param	array	$data
     * @param	intval	$page
     * @return	string
     */
    public function page_url($data, $page = 0) {

        if (!$data) {
            return '自定义页面数据不存在';
        }

        $page && $data['page'] = $page = is_numeric($page) ? max((int)$page, 1) : $page;
        $page == 1 && $page = 0;

        $rule = [
            'page' => $data['setting']['urlrule'],
            'page_page' => $data['setting']['urlrule_page'],
            'catjoin' => '/',
        ];
        if ($rule && $rule['page']) {
            // URL模式为自定义，且已经设置规则
            $data['pdirname'] == '/' && $data['pdirname'] = '';
            $data['dirname'] == '/' && $data['dirname'] = '';
            $data['pdirname'] .= $data['dirname'];
            $data['pdirname'] = str_replace('/', $rule['catjoin'], $data['pdirname']);
            $url = $page ? $rule['page_page'] : $rule['page'];
            return \Phpcmf\Service::L('router')->get_url_value($data, $url, '/');
        }

        return \Phpcmf\Service::L('router')->url_prefix('php') . 's=page&id=' . $data['id'] . ($page ? '&page=' . $page : '');
    }

    // 缓存
    public function cache($siteid = SITE_ID) {

        $table = $this->dbprefix($siteid.'_page');
        if (!\Phpcmf\Service::M()->db->tableExists($table)) {
            $sql = file_get_contents(dr_get_app_dir('page').'Config/Install_site.sql');
            $this->query_all(str_replace('{dbprefix}',  $this->prefix.$siteid.'_', $sql));
        }

        if (!$this->db->table('field')->where('fieldname', 'attachment')->where('relatedid', $siteid)->where('relatedname', 'page')->orderBy('displayorder ASC,id ASC')->get()->getRowArray()) {
            $this->db->simpleQuery('INSERT INTO `'.$this->dbprefix('field').'` VALUES(NULL, \'相关附件\', \'attachment\', \'Files\', '.$siteid.', \'page\', 1, 1, 1, 1, 0, 0, \'a:2:{s:6:\\"option\\";a:5:{s:5:\\"width\\";s:3:\\"80%\\";s:4:\\"size\\";s:1:\\"2\\";s:5:\\"count\\";s:2:\\"10\\";s:3:\\"ext\\";s:31:\\"jpg,gif,png,ppt,doc,xls,rar,zip\\";s:10:\\"uploadpath\\";s:0:\\"\\";}s:8:\\"validate\\";a:9:{s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";s:0:\\"\\";s:6:\\"isedit\\";s:1:\\"0\\";s:3:\\"xss\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";s:0:\\"\\";s:8:\\"formattr\\";s:0:\\"\\";}}\', 0)');
        }

        if (!$this->db->table('field')->where('fieldname', 'content')->where('relatedid', $siteid)->where('relatedname', 'page')->orderBy('displayorder ASC,id ASC')->get()->getRowArray()) {
            $this->db->simpleQuery('INSERT INTO `'.$this->dbprefix('field').'` VALUES(NULL, \'页面内容\', \'content\', \'Ueditor\', '.$siteid.', \'page\', 1, 1, 1, 1, 0, 0, \'a:2:{s:6:\\"option\\";a:7:{s:5:\\"width\\";s:3:\\"90%\\";s:6:\\"height\\";s:3:\\"400\\";s:4:\\"mode\\";s:1:\\"1\\";s:4:\\"tool\\";s:0:\\"\\";s:5:\\"mode2\\";s:1:\\"1\\";s:5:\\"tool2\\";s:0:\\"\\";s:5:\\"value\\";s:0:\\"\\";}s:8:\\"validate\\";a:9:{s:8:\\"required\\";s:1:\\"1\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";s:0:\\"\\";s:6:\\"isedit\\";s:1:\\"0\\";s:3:\\"xss\\";s:1:\\"1\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";s:0:\\"\\";s:8:\\"formattr\\";s:0:\\"\\";}}\', 0)');

        }

        $cache = $cache2 = [];

        // 自定义字段
        $field = $this->db->table('field')->where('disabled', 0)->where('relatedid', $siteid)->where('relatedname', 'page')->orderBy('displayorder ASC,id ASC')->get()->getResultArray();
        if ($field) {
            foreach ($field as $f) {
                $f['setting'] = dr_string2array($f['setting']);
                $cache2[$f['fieldname']] = $f;
            }
        }

        // 全部栏目
        $data = $this->set_siteid($siteid)->repair();
        if ($data) {
            foreach ($data as $t) {
                $attachment = dr_string2array($t['attachment']);
                $t['attachment'] = [];
                if ($attachment) {
                    foreach ($attachment['file'] as $i => $file) {
                        $t['attachment'][] = [
                            'file' => $file,
                            'title' => $attachment['title'][$i]
                        ];
                    }
                }
                $pid = explode(',', $t['pids']);
                $t['topid'] = isset($pid[1]) ? $pid[1] : $t['id'];
                if ($t['topid'] && $t['topid'] != $t['id']) {
                    // 继承第一级的
                    $t['setting']['html_dir'] = $data[$t['topid']]['setting']['html_dir'];
                    $t['setting']['html_domain'] = $data[$t['topid']]['setting']['html_domain'];
                    $t['setting']['html_mobile_domain'] = $data[$t['topid']]['setting']['html_mobile_domain'];
                }
                $t['url'] = $this->_update_url($t, $siteid);
                $t['pageids'] = explode(',', $t['childids']);
                $cache['data'][$t['id']] = \Phpcmf\Service::L('Field')->app('')->format_value($cache2, $t);
                $cache['dir'][$t['dirname']] = $t['id'];
            }
        }

        \Phpcmf\Service::L('cache')->set_file('page-'.$siteid, $cache);
        \Phpcmf\Service::L('cache')->set_file('page-'.$siteid.'-field', $cache2);

        return $cache;
    }



}