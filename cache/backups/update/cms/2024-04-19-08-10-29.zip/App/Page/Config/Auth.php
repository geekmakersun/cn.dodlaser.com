<?php

/**
 * 嵌入权限页面
 **/

return [

    'app' => [
        'page.html'
    ],


];