<?php

return [

    'type' => 'app',
    'name' => '自定义页面',
    'author' => '迅睿云软件',
    'icon' => 'fa fa-safari',

];