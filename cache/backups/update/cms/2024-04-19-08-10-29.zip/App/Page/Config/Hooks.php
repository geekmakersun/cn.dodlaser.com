<?php

/**
 * 单页面包屑导航
 *
 * @param   intval  $id
 * @param   string  $symbol
 * @param   string  $html
 * @return  string
 */
function dr_page_catpos($id, $symbol = ' > ', $html = '') {

    if (!$id) {
        return '';
    }

    $page = \Phpcmf\Service::C()->get_cache('page-'.SITE_ID, 'data');
    if (!isset($page[$id])) {
        return '';
    }

    $name = [];
    $array = explode(',', $page[$id]['pids']);
    $array[] = $id;

    foreach ($array as $i) {
        if ($i && $page[$i]) {
            $murl = dr_url_prefix($page[$i]['url']);
            $name[] = $html ? str_replace(['[url]', '[name]'], [$murl, $page[$i]['name']], $html) : "<a href=\"{$murl}\">{$page[$i]['name']}</a>";
        }
    }

    return implode($symbol, array_unique($name));
}



/**
 * 单页层次关系
 *
 * @param   intval  $id
 * @param   string  $symbol
 * @return  string
 */
function dr_get_page_pname($id, $symbol = '_', $page) {

    if (!$page[$id]['pids']) {
        return $page[$id]['name'];
    }

    $name = [];
    $array = explode(',', $page[$id]['pids']);

    foreach ($array as $i) {
        $i && $page[$i] && $name[] = $page[$i]['name'];
    }

    $name[] = $page[$id]['name'];

    $name = array_unique($name);

    krsort($name);

    return implode($symbol, $name);
}


/**
 * 栏目下级或者同级栏目
 * $data 整个栏目数组
 * $catid 当前栏目id
 */
function dr_related_page($data, $catid) {

    if (!$data) {
        return [[], []];
    }

    $my = $data[$catid];
    $related = $parent = [];

    if ($my['child']) {
        // 当存在子栏目时就显示下级子栏目
        $parent = $my;
        foreach ($data as $t) {
            if (!$t['show']) {
                continue;
            }
            if ($t['pid'] == $my['id']) {
                $t['url'] = dr_url_prefix($t['url'], defined('MOD_DIR') ? MOD_DIR : '');
                $related[$t['id']] = $t;
            }
        }
    } elseif ($my['pid']) {
        // 当属于子栏目时就显示同级别栏目
        foreach ($data as $t) {
            if (!$t['show']) {
                continue;
            }
            if ($t['pid'] == $my['pid']) {
                $t['url'] = dr_url_prefix($t['url'], defined('MOD_DIR') ? MOD_DIR : '');
                $related[$t['id']] = $t;
                $parent = $my['child'] ? $my : $data[$t['pid']];
            }
        }
    } else {
        // 显示顶级栏目
        if (!$data) {
            return [[], []];
        }
        $parent = $my;
        foreach ($data as $t) {
            if (!$t['show']) {
                continue;
            }
            if ($t['pid'] == 0) {
                $t['url'] = dr_url_prefix($t['url'], defined('MOD_DIR') ? MOD_DIR : '');
                $related[$t['id']] = $t;
            }
        }
    }

    $parent['url'] = dr_url_prefix($parent['url'], defined('MOD_DIR') ? MOD_DIR : '');

    return [$parent, $related];
}
