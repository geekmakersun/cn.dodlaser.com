<?php

/**
 * 菜单配置
 */


return [

    'admin' => [

        'app' => [

            'left' => [


                'app-plugin' => [
                    'link' => [
                        [
                            'name' => '自定义页面',
                            'icon' => 'fa fa-safari',
                            'uri' => 'page/home/index',
                        ],

                    ]
                ],
            ],



        ],

    ],
];