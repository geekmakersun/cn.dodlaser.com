<?php

return [

    'id' => '363',
    'vip' => '1',
    'cms' => '4.6.2',
    'version' => '3.5',
    'license' => '5E632913BF096E49880CF8B92D53C99711',
    'updatetime' => '2023-12-05 04:46:14',
    'downtime' => '2024-04-18 20:58:52',

];
