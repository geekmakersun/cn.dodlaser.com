<?php

return [

    'type' => 'app',
    'name' => 'Api接口',
    'author' => '迅睿云软件',
    'uri' => 'httpapi/auth/index',
    'icon' => 'fa fa-plug',

];