DROP TABLE IF EXISTS `{dbprefix}api_auth`;
DROP TABLE IF EXISTS `{dbprefix}api_http`;

