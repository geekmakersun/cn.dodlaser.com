<?php namespace Phpcmf\Model\Sites;


class Sites extends \Phpcmf\Model
{

    public function create($siteid, $data) {

        if (IS_USE_MODULE) {
            // 复制站点1的栏目结构
            $sql = $this->db->query("SHOW CREATE TABLE `".$this->dbprefix('1_share_category')."`")->getRowArray();
            $sql = str_replace(
                array($sql['Table'], 'CREATE TABLE'),
                array('{tablename}', 'CREATE TABLE IF NOT EXISTS'),
                $sql['Create Table']
            );
            $this->db->simpleQuery(str_replace('{tablename}', $this->dbprefix($siteid.'_share_category'), dr_format_create_sql($sql)));
            $this->db->table($siteid.'_share_category')->truncate();

            $this->db->simpleQuery(dr_format_create_sql("
            CREATE TABLE IF NOT EXISTS `".$this->dbprefix($siteid.'_share_index')."` (
              `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
              `mid` varchar(20) NOT NULL COMMENT '模块目录',
              PRIMARY KEY (`id`),
              KEY `mid` (`mid`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='共享模块内容索引表';
            "));
        }

        if (is_file(MYPATH.'Config/Install_site.sql')) {
            $s = file_get_contents(MYPATH.'Config/Install_site.sql');
            $sql = str_replace('{dbprefix}', $this->prefix.$siteid.'_', $s);
            $this->query_all($sql);
        }

        // 创建
        if (is_file(MYPATH.'Config/Install.php')) {
            require MYPATH.'Config/Install.php';
        }

        // 执行应用插件的站点sql语句
        $local = \Phpcmf\Service::Apps(true);
        foreach ($local as $dir => $path) {
            $cfg = require $path.'Config/App.php';
            if ($cfg['type'] == 'app' && is_file($path.'Config/Install_site.sql')) {
                // 避免模块未安装时被执行创建
                $sql = file_get_contents($path.'Config/Install_site.sql');
                $this->query_all(str_replace('{dbprefix}',  $this->prefix.$siteid.'_', $sql));
            }
        }

        \Phpcmf\Service::M('cache')->update_webpath('Web', $data['webpath'], [
            'SITE_ID' => $siteid
        ]);

        return $siteid;
    }

    // 删除站点
    public function delete_site($ids) {

        if (!$ids) {
            return dr_return_data(0, dr_lang('参数不存在'));
        }

        $database = \Phpcmf\Service::M()->db->query('show table status')->getResultArray();

        // 删除表
        foreach ($ids as $siteid) {
            if ($siteid > 1) {
                $this->db->table('site')->where('id', $siteid)->delete();
                // 删除表
                $table = $this->dbprefix($siteid.'_');
                foreach ($database as $t) {
                    if (strpos($t['Name'], $table) === 0) {
                        $this->db->query('DROP TABLE IF EXISTS `'.$t['Name'].'`;');
                        log_message('error', '删除站点【'.$siteid.'】时联动删除表：'.$t['Name']);
                    }
                }
            }
        }

        return dr_return_data(1, 'ok');
    }

    public function cache($siteid = SITE_ID) {


        if (IS_USE_MODULE) {

            $table = $this->dbprefix($siteid.'_share_category');
            if (!\Phpcmf\Service::M()->db->tableExists($table)) {
                $sql = $this->db->query("SHOW CREATE TABLE `".$this->dbprefix('1_share_category')."`")->getRowArray();
                $sql = str_replace(
                    array($sql['Table'], 'CREATE TABLE'),
                    array('{tablename}', 'CREATE TABLE IF NOT EXISTS'),
                    $sql['Create Table']
                );
                $this->db->simpleQuery(str_replace('{tablename}', $table, dr_format_create_sql($sql)));
                //$this->db->table($table)->truncate();
            }

            $table = $this->dbprefix($siteid.'_share_index');
            if (!\Phpcmf\Service::M()->db->tableExists($table)) {
                $this->db->simpleQuery(dr_format_create_sql("
                CREATE TABLE IF NOT EXISTS `".$this->dbprefix($siteid.'_share_index')."` (
                  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                  `mid` varchar(20) NOT NULL COMMENT '模块目录',
                  PRIMARY KEY (`id`),
                  KEY `mid` (`mid`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='共享模块内容索引表';
                "));
            }

        }


    }

}