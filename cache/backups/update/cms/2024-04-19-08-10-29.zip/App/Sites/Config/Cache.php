<?php

/**
 * 缓存参数配置
 *
 * 模型名称 => 项目目录
 *
 **/

return [

    'sites' => 'sites'

];