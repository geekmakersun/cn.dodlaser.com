<?php

return [

    'type' => 'app',
    'name' => '多网站系统',
    'author' => '迅睿云软件',
    'icon' => 'fa fa-share-alt',

];