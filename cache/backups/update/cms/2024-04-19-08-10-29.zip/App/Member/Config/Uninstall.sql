
DROP TABLE IF EXISTS `{dbprefix}member_login`;
DROP TABLE IF EXISTS `{dbprefix}member_group`;
DROP TABLE IF EXISTS `{dbprefix}member_level`;
DROP TABLE IF EXISTS `{dbprefix}member_group_index`;
DROP TABLE IF EXISTS `{dbprefix}member_group_verify`;
DROP TABLE IF EXISTS `{dbprefix}member_menu`;
DROP TABLE IF EXISTS `{dbprefix}member_oauth`;
DROP TABLE IF EXISTS `{dbprefix}member_setting`;
DROP TABLE IF EXISTS `{dbprefix}admin_verify`;