<?php

return [

    'type' => 'module',
    'name' => '产品',
    'icon' => 'fa fa-life-bouy',
    'system' => '1',

];