<?php

return [

    'id' => '889',
    'vip' => '1',
    'cms' => '4.6.2',
    'version' => '1.4',
    'license' => '5E632913BF096E49880CF8B92D53C99711',
    'updatetime' => '2023-12-09 03:15:10',
    'downtime' => '2024-04-18 20:58:52',

];
