<?php

return [

    'id' => '710',
    'vip' => '1',
    'cms' => '4.6.2',
    'version' => '2.3',
    'license' => '5E632913BF096E49880CF8B92D53C99711',
    'updatetime' => '2024-01-14 17:07:49',
    'downtime' => '2024-04-18 20:58:52',

];
