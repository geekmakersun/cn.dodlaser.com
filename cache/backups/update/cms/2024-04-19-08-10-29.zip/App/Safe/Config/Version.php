<?php

return [

    'id' => '399',
    'vip' => '1',
    'version' => '4.1',
    'license' => '5E632913BF096E49880CF8B92D53C99711',
    'updatetime' => '2023-05-17 23:18:20',
    'downtime' => '2023-06-09 19:56:03',

];
