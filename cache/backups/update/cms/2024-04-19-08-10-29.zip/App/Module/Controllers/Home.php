<?php namespace Phpcmf\Controllers;

class Home extends \Phpcmf\App
{

    public function index() {


    }

}
