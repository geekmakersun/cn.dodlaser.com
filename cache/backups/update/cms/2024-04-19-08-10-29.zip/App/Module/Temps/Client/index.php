<?php

/**
 * Cms 自定义终端入口程序
 */

define('SITE_ID', '{SITE_ID}');
define('IS_CLIENT', '{CLIENT}');
define('FIX_WEB_DIR', '{FIX_WEB_DIR}');

// 执行主程序
require '../index.php';