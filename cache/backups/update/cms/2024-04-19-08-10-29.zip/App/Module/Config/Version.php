<?php

/**
 * 程序版本控制
 */

return [

    'id' => '',
    'version' => 'dev',
    'license' => '00000000000000000',
    'updatetime' => '2022-3-1',

];