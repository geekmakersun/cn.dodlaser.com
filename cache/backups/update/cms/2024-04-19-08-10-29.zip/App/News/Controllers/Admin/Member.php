<?php namespace Phpcmf\Controllers\Admin;

/**
 * 二次开发时可以修改本文件，不影响升级覆盖
 */

class Member extends \Phpcmf\Admin\Member
{

	public function index() {
		$this->_Index();
	}
}
