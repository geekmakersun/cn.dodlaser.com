<?php

return [

    'id' => '428',
    'vip' => '1',
    'version' => '3.26',
    'license' => '1646205886486',
    'updatetime' => '2023-09-16 04:45:06',
    'downtime' => '2023-11-26 11:29:06',

];
