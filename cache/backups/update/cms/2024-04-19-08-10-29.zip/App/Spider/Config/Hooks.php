<?php
/**
 * 插件初始化程序
 */

\Phpcmf\Hooks::on('cms_view', function($data) {
    \Phpcmf\Service::M('spider', 'spider')->run($data);
});