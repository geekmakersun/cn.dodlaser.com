<?php

/**
 * 菜单配置
 */


return [

    'admin' => [

        'app' => [
            'left' => [

                'app-plugin' => [
                    'link' => [
                        [
                            'name' => '蜘蛛监控',
                            'icon' => 'fa fa-bug',
                            'uri' => 'spider/home/index',
                        ],
                    ]
                ],
            ],
        ],

    ],
];