DROP TABLE IF EXISTS `{dbprefix}app_spider`;
CREATE TABLE IF NOT EXISTS `{dbprefix}app_spider` (
  `id` INT(10) unsigned NOT NULL AUTO_INCREMENT,
  `site` int(10) unsigned NOT NULL COMMENT '站点id',
  `spider` int(10) unsigned NOT NULL COMMENT '蜘蛛id',
  `domain` varchar(255) NOT NULL COMMENT '受访域名',
  `title` varchar(255) NOT NULL COMMENT '页面标题',
  `url` varchar(255) NOT NULL COMMENT '收放地址',
  `referrer` varchar(255) NOT NULL COMMENT '来访地址',
  `mobile` tinyint(1) unsigned NOT NULL COMMENT '是否移动端',
  `agent` varchar(255) NOT NULL COMMENT '客户端',
  `ip` varchar(255) NOT NULL COMMENT 'ip地址',
  `inputtime` int(10) NOT NULL COMMENT '访问时间',
  PRIMARY KEY (`id`),
  KEY `site` (`site`),
  KEY `spider` (`spider`),
  KEY `mobile` (`mobile`),
  KEY `domain` (`domain`),
  KEY `inputtime` (`inputtime`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='蜘蛛监控记录';

